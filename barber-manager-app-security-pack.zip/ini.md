# Project: Barber-manager-app (Karpathy Protocol)
- Stack: Next.js, Tailwind CSS, Supabase, Supabase Auth
- Core Behavioral Pillars: 
  1. Think Before Coding (State assumptions, surface tradeoffs)
  2. Simplicity First (Minimum viable code, no speculative features)
  3. Surgical Changes (Clean up own mess, no unsolicited refactors)
  4. Goal-Driven Execution (Verifiable success criteria, test-driven fixes)
- GITHUB SECURITY: Never commit .env files, API keys, or credentials. Use .gitignore rigorously.
- COMMIT CONVENTIONS: Use descriptive commit messages (e.g., conventional commits).
- REMOTE SYNC: Always pull latest changes before starting a new task to avoid merge conflicts.
- PROJECT REPO: https://github.com/risso-patron/barber-manager-app.git